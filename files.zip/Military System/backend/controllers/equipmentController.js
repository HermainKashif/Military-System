const { sql, config } = require("../dbconfig");

// GET all equipment
const getAllEquipment = async (req, res) => {
  try {
    await sql.connect(config);
    const result = await sql.query`SELECT * FROM Equipment`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET equipment by EQ_ID
const getEquipmentById = async (req, res) => {
  const id = req.params.id;
  try {
    await sql.connect(config);
    const result = await sql.query`SELECT * FROM Equipment WHERE EQ_ID = ${id}`;
    if (result.recordset.length === 0)
      return res.status(404).json({ message: "Not found" });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// CREATE new equipment
const createEquipment = async (req, res) => {
  const { EQ_ID, Name, Type, UnitID, SerialNumber, Status, AcquiredDate } =
    req.body;
  try {
    await sql.connect(config);
    await sql.query`
      INSERT INTO Equipment (EQ_ID, Name, Type, UnitID, SerialNumber, Status, AcquiredDate)
      VALUES (${EQ_ID}, ${Name}, ${Type}, ${UnitID}, ${SerialNumber}, ${Status}, ${AcquiredDate})
    `;
    res.status(201).json({ message: "Equipment created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// UPDATE equipment by EQ_ID
const updateEquipment = async (req, res) => {
  const id = req.params.id;
  const { Name, Type, UnitID, SerialNumber, Status, AcquiredDate } = req.body;
  try {
    await sql.connect(config);
    const result = await sql.query`
      UPDATE Equipment
      SET Name = ${Name}, Type = ${Type}, UnitID = ${UnitID}, SerialNumber = ${SerialNumber}, Status = ${Status}, AcquiredDate = ${AcquiredDate}
      WHERE EQ_ID = ${id}
    `;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Equipment updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE equipment by EQ_ID
const deleteEquipment = async (req, res) => {
  const id = req.params.id;
  try {
    await sql.connect(config);
    const result = await sql.query`DELETE FROM Equipment WHERE EQ_ID = ${id}`;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Equipment deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getAllEquipment,
  getEquipmentById,
  createEquipment,
  updateEquipment,
  deleteEquipment,
};
