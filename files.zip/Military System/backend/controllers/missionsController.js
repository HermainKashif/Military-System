const { sql, config } = require("../dbconfig");

// GET all missions
const getAllMissions = async (req, res) => {
  try {
    await sql.connect(config);
    const result = await sql.query`SELECT * FROM Missions`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET mission by ID
const getMissionById = async (req, res) => {
  try {
    await sql.connect(config);
    const id = req.params.id;
    const result = await sql.query`SELECT * FROM Missions WHERE MI_ID = ${id}`;
    if (result.recordset.length === 0)
      return res.status(404).json({ message: "Not found" });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// CREATE new mission
const createMission = async (req, res) => {
  const { MI_ID, MissionName, StartTime, EndTime, OP_ID, AssignedUnitID } =
    req.body;
  try {
    await sql.connect(config);
    await sql.query`
      INSERT INTO Missions (MI_ID, MissionName, StartTime, EndTime, OP_ID, AssignedUnitID)
      VALUES (${MI_ID}, ${MissionName}, ${StartTime}, ${EndTime}, ${OP_ID}, ${AssignedUnitID})
    `;
    res.status(201).json({ message: "Mission created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// UPDATE mission by ID
const updateMission = async (req, res) => {
  const id = req.params.id;
  const { MissionName, StartTime, EndTime, OP_ID, AssignedUnitID } = req.body;
  try {
    await sql.connect(config);
    const result = await sql.query`
      UPDATE Missions
      SET MissionName = ${MissionName},
          StartTime = ${StartTime},
          EndTime = ${EndTime},
          OP_ID = ${OP_ID},
          AssignedUnitID = ${AssignedUnitID}
      WHERE MI_ID = ${id}
    `;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Mission updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE mission by ID
const deleteMission = async (req, res) => {
  const id = req.params.id;
  try {
    await sql.connect(config);
    const result = await sql.query`DELETE FROM Missions WHERE MI_ID = ${id}`;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Mission deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getAllMissions,
  getMissionById,
  createMission,
  updateMission,
  deleteMission,
};
