const { sql, config } = require("../dbconfig");

// GET all operations
const getAllOperations = async (req, res) => {
  try {
    await sql.connect(config);
    const result = await sql.query`SELECT * FROM Operations`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET operation by OP_ID
const getOperationById = async (req, res) => {
  try {
    await sql.connect(config);
    const op_id = req.params.id;
    const result =
      await sql.query`SELECT * FROM Operations WHERE OP_ID = ${op_id}`;
    if (result.recordset.length === 0)
      return res.status(404).json({ message: "Not found" });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// CREATE new operation
const createOperation = async (req, res) => {
  const { OP_ID, OP_Name, StartDate, EndDate, Status, Objective, CoalitionID } =
    req.body;

  try {
    await sql.connect(config);
    await sql.query`
      INSERT INTO Operations (OP_ID, OP_Name, StartDate, EndDate, Status, Objective, CoalitionID)
      VALUES (${OP_ID}, ${OP_Name}, ${StartDate}, ${EndDate}, ${Status}, ${Objective}, ${CoalitionID})
    `;
    res.status(201).json({ message: "Operation created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// UPDATE operation by OP_ID
const updateOperation = async (req, res) => {
  const OP_ID = req.params.id;
  const { OP_Name, StartDate, EndDate, Status, Objective, CoalitionID } =
    req.body;

  console.log(OP_Name);
  try {
    await sql.connect(config);
    const result = await sql.query`
      UPDATE Operations
      SET OP_Name = ${OP_Name}, StartDate = ${StartDate}, EndDate = ${EndDate},
          Status = ${Status}, Objective = ${Objective}, CoalitionID = ${CoalitionID}
      WHERE OP_ID = ${OP_ID}
    `;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Operation updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE operation by OP_ID
const deleteOperation = async (req, res) => {
  const OP_ID = req.params.id;
  try {
    await sql.connect(config);
    const result =
      await sql.query`DELETE FROM Operations WHERE OP_ID = ${OP_ID}`;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Operation deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getAllOperations,
  getOperationById,
  createOperation,
  updateOperation,
  deleteOperation,
};
