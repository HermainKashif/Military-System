const { sql, config } = require("../dbconfig");

// GET all personnel
const getAllPersonnel = async (req, res) => {
  try {
    await sql.connect(config);
    const result = await sql.query`SELECT * FROM Personnel`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET personnel by P_ID
const getPersonnelById = async (req, res) => {
  try {
    await sql.connect(config);
    const id = req.params.id;
    const result = await sql.query`
      SELECT * FROM Personnel WHERE P_ID = ${id}
    `;
    if (result.recordset.length === 0)
      return res.status(404).json({ message: "Not found" });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// CREATE new personnel
const createPersonnel = async (req, res) => {
  const { P_ID, Name, Rank, UnitID } = req.body;
  try {
    await sql.connect(config);
    await sql.query`
      INSERT INTO Personnel (P_ID, Name, Rank, UnitID) 
      VALUES (${P_ID}, ${Name}, ${Rank}, ${UnitID})
    `;
    res.status(201).json({ message: "Personnel created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// UPDATE personnel by P_ID
const updatePersonnel = async (req, res) => {
  const id = req.params.id;
  const { Name, Rank, UnitID } = req.body;
  try {
    await sql.connect(config);
    const result = await sql.query`
      UPDATE Personnel 
      SET Name = ${Name}, Rank = ${Rank}, UnitID = ${UnitID} 
      WHERE P_ID = ${id}
    `;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Personnel updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE personnel by P_ID
const deletePersonnel = async (req, res) => {
  const id = req.params.id;
  try {
    await sql.connect(config);
    const result = await sql.query`
      DELETE FROM Personnel WHERE P_ID = ${id}
    `;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Personnel deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getAllPersonnel,
  getPersonnelById,
  createPersonnel,
  updatePersonnel,
  deletePersonnel,
};
