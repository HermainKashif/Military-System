const { sql, config } = require("../dbconfig");

const allowedTables = {
  Personnel: "Personnel",
  Units: "Units",
  Operations: "Operations",
  Missions: "Missions",
  Equipment: "Equipment",
};

// Allowed searchable fields per table (to prevent SQL injection)
const allowedFields = {
  Personnel: ["P_ID", "Name", "Rank", "UnitID"],
  Units: [
    "UnitID",
    "UnitName",
    "Country",
    "Type",
    "OfficerID",
    "Deployment",
    "OP_ID",
  ],
  Operations: [
    "OP_ID",
    "OP_Name",
    "StartDate",
    "EndDate",
    "Objective",
    "Status",
    "CoalitionID",
  ],
  Missions: [
    "MI_ID",
    "MissionName",
    "StartTime",
    "EndTime",
    "OP_ID",
    "AssignedUnitID",
  ],
  Equipment: [
    "EQ_ID",
    "Name",
    "Type",
    "UnitID",
    "SerialNumber",
    "Status",
    "AcquiredDate",
  ],
};

// List of fields considered numeric (IDs)
const numericFields = [
  "P_ID",
  "UnitID",
  "OfficerID",
  "OP_ID",
  "MI_ID",
  "EQ_ID",
  "AssignedUnitID",
];

async function searchRecords(req, res) {
  const { table, field, keyword } = req.query;

  // Validate inputs
  if (!table || !field || !keyword) {
    return res
      .status(400)
      .json({ message: "Please provide table, field and keyword parameters." });
  }

  if (!allowedTables[table]) {
    return res.status(400).json({ message: "Invalid table name." });
  }

  if (!allowedFields[table].includes(field)) {
    return res
      .status(400)
      .json({ message: "Invalid field name for the selected table." });
  }

  try {
    let pool = await sql.connect(config);

    let query;
    let inputKeyword;

    if (numericFields.includes(field)) {
      // For numeric fields, do exact match
      query = `SELECT * FROM ${allowedTables[table]} WHERE ${field} = @keyword`;
      // Convert keyword to number (if possible)
      const numericValue = Number(keyword);
      if (isNaN(numericValue)) {
        // If keyword is not a number, no results can be returned
        return res.json([]);
      }
      inputKeyword = numericValue;
    } else {
      // For text fields, do LIKE search with %
      query = `SELECT * FROM ${allowedTables[table]} WHERE ${field} LIKE @keyword`;
      inputKeyword = `%${keyword}%`;
    }

    const result = await pool
      .request()
      .input(
        "keyword",
        numericFields.includes(field) ? sql.Int : sql.NVarChar,
        inputKeyword
      )
      .query(query);

    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
}

module.exports = { searchRecords };
