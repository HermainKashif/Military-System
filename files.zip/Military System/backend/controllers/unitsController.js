const { sql, config } = require("../dbconfig");

// GET all units
const getAllUnits = async (req, res) => {
  try {
    await sql.connect(config);
    const result = await sql.query`SELECT * FROM Units`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET unit by UnitID
const getUnitById = async (req, res) => {
  try {
    await sql.connect(config);
    const unitId = req.params.id;
    const result =
      await sql.query`SELECT * FROM Units WHERE UnitID = ${unitId}`;
    if (result.recordset.length === 0)
      return res.status(404).json({ message: "Not found" });
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// CREATE new unit
const createUnit = async (req, res) => {
  const {
    UnitID,
    UnitName,
    Country,
    Type,
    OfficerID,
    Deployment,
    OperationID,
  } = req.body;
  try {
    await sql.connect(config);
    await sql.query`
      INSERT INTO Units (UnitID, UnitName, Country, Type, OfficerID, Deployment, OP_ID) 
      VALUES (${UnitID}, ${UnitName}, ${Country}, ${Type}, ${OfficerID}, ${Deployment}, ${OperationID})
    `;
    res.status(201).json({ message: "Unit created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// UPDATE unit by UnitID
const updateUnit = async (req, res) => {
  const unitId = req.params.id;
  const { UnitName, Country, Type, OfficerID, Deployment, OperationID } =
    req.body;
  try {
    await sql.connect(config);
    const result = await sql.query`
      UPDATE Units
      SET UnitName = ${UnitName},
          Country = ${Country},
          Type = ${Type},
          OfficerID = ${OfficerID},
          Deployment = ${Deployment},
          OP_ID = ${OperationID}
      WHERE UnitID = ${unitId}
    `;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Unit updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE unit by UnitID
const deleteUnit = async (req, res) => {
  const unitId = req.params.id;
  try {
    await sql.connect(config);
    const result = await sql.query`DELETE FROM Units WHERE UnitID = ${unitId}`;
    if (result.rowsAffected[0] === 0)
      return res.status(404).json({ message: "Not found" });
    res.json({ message: "Unit deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getAllUnits,
  getUnitById,
  createUnit,
  updateUnit,
  deleteUnit,
};
