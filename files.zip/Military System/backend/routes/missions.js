const express = require("express");
const router = express.Router();

const {
  getAllMissions,
  getMissionById,
  createMission,
  updateMission,
  deleteMission,
} = require("../controllers/missionsController");

router.get("/", getAllMissions);
router.get("/:id", getMissionById);
router.post("/", createMission);
router.put("/:id", updateMission);
router.delete("/:id", deleteMission);

module.exports = router;
