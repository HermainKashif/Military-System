const express = require("express");
const router = express.Router();

const {
  getAllOperations,
  getOperationById,
  createOperation,
  updateOperation,
  deleteOperation,
} = require("../controllers/operationsController");

router.get("/", getAllOperations);
router.get("/:id", getOperationById);
router.post("/", createOperation);
router.put("/:id", updateOperation);
router.delete("/:id", deleteOperation);

module.exports = router;
