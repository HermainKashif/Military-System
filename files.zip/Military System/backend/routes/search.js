const express = require("express");
const router = express.Router();
const { searchRecords } = require("../controllers/searchController");

router.get("/", searchRecords);

module.exports = router;
