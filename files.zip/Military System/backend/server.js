require("dotenv").config();
const express = require("express");
const { sql, config } = require("./dbconfig");

const app = express();
app.use(express.json());

const port = process.env.PORT || 5000;
////////////////////////////////////////////////////////////////
const cors = require("cors");
app.use(cors());

const searchRouter = require("./routes/search");
app.use("/api/search", searchRouter);

const personnelRouter = require("./routes/personnel");

app.use("/api/personnel", personnelRouter);

const unitsRouter = require("./routes/units");
app.use("/api/units", unitsRouter);

const operationRouter = require("./routes/operations");
app.use("/api/operations", operationRouter);

const missionsRouter = require("./routes/missions");
app.use("/api/missions", missionsRouter);

const equipmentRouter = require("./routes/equipment");
app.use("/api/equipment", equipmentRouter);

app.listen(port, () => console.log(`Server running on port ${port}`));

//////////////////////////////////////////////////////////////
