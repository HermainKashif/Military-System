CREATE TABLE Operations (
    OP_ID VARCHAR(50) PRIMARY KEY,
    OP_Name VARCHAR(100),
    StartDate DATE,
    EndDate DATE,
    Objective VARCHAR(200),
    Status VARCHAR(50),
    CoalitionID VARCHAR(50)
);

CREATE TABLE Units (
    UnitID INT PRIMARY KEY,
    UnitName VARCHAR(50),
    Country VARCHAR(50),
    Type VARCHAR(50),
    OfficerID INT,
    Deployment VARCHAR(50),
    OP_ID VARCHAR(50),
    FOREIGN KEY (OP_ID) REFERENCES Operations(OP_ID)
);

CREATE TABLE Personnel (
    P_ID INT PRIMARY KEY,
    Name VARCHAR(50),
    Rank VARCHAR(50),
    UnitID INT,
    FOREIGN KEY (UnitID) REFERENCES Units(UnitID)
);

CREATE TABLE Missions (
    MI_ID VARCHAR(50) PRIMARY KEY,
    MissionName VARCHAR(200),
    StartTime DATETIME,
    EndTime DATETIME,
    OP_ID VARCHAR(50),
    AssignedUnitID INT,
    FOREIGN KEY (OP_ID) REFERENCES Operations(OP_ID),
    FOREIGN KEY (AssignedUnitID) REFERENCES Units(UnitID)
);

CREATE TABLE Equipment (
    EQ_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Type VARCHAR(50),
    UnitID INT,
    SerialNumber VARCHAR(100),
    Status VARCHAR(50),
    AcquiredDate DATE,
    FOREIGN KEY (UnitID) REFERENCES Units(UnitID)
);


USE military_database;

INSERT INTO Operations (OP_ID, OP_Name, StartDate, EndDate, Objective, Status, CoalitionID) VALUES
('OP001', 'Zarb-e-Azb', '2022-01-10', '2022-04-20', 'Clear terrorist zones', 'Completed', 'COA01'),
('OP002', 'Rah-e-Nijat', '2023-03-15', '2023-06-30', 'Secure border area', 'Ongoing', 'COA02'),
('OP003', 'Margalla Shield', '2024-05-01', '2024-07-10', 'Protect Islamabad', 'Planned', 'COA03'),
('OP004', 'Sarsabz Mission', '2023-11-01', '2024-01-15', 'Guard rural belt', 'Completed', 'COA04'),
('OP005', 'Black Storm', '2024-02-01', '2024-04-01', 'Catch sleeper cells', 'Ongoing', 'COA05');


INSERT INTO Units (UnitID, UnitName, Country, Type, OfficerID, Deployment, OP_ID) VALUES
(101, '1st Infantry', 'Pakistan', 'Infantry', 1001, 'Waziristan', 'OP001'),
(102, 'Bravo Artillery', 'Pakistan', 'Artillery', 1002, 'Lahore', 'OP002'),
(103, 'Sky Hawks', 'Pakistan', 'Airborne', 1003, 'Peshawar', 'OP003'),
(104, 'Desert Tigers', 'Pakistan', 'Infantry', 1004, 'Bahawalpur', 'OP004'),
(105, 'Thunder Squad', 'Pakistan', 'Airborne', 1005, 'Quetta', 'OP005');


INSERT INTO Personnel (P_ID, Name, Rank, UnitID) VALUES
(1001, 'Adeel Khan', 'Major', 101),
(1002, 'Imran Ali', 'Captain', 102),
(1003, 'Bilal Qureshi', 'Lieutenant', 103),
(1004, 'Usman Rafiq', 'Colonel', 104),
(1005, 'Yasir Malik', 'Brigadier', 105);


INSERT INTO Missions (MI_ID, MissionName, StartTime, EndTime, OP_ID, AssignedUnitID) VALUES
('MI001', 'Sweep Valley', '2022-02-01 05:00', '2022-02-01 18:00', 'OP001', 101),
('MI002', 'Silent Watch', '2023-04-10 03:00', '2023-04-10 16:30', 'OP002', 102),
('MI003', 'Sky Patrol', '2024-05-15 08:00', '2024-05-15 20:00', 'OP003', 103),
('MI004', 'Desert Eye', '2023-12-05 06:30', '2023-12-05 18:00', 'OP004', 104),
('MI005', 'Black Thunder', '2024-02-15 07:00', '2024-02-15 21:00', 'OP005', 105);


INSERT INTO Equipment (EQ_ID, Name, Type, UnitID, SerialNumber, Status, AcquiredDate) VALUES
(201, 'APC Zarrar', 'Vehicle', 101, 'PKV-7893', 'Operational', '2021-10-01'),
(202, 'M777 Howitzer', 'Weapon', 102, 'ART-5541', 'Operational', '2022-06-12'),
(203, 'Bell 412', 'Aircraft', 103, 'AIR-2201', 'Under Repair', '2023-03-15'),
(204, 'Radio Alpha 5', 'Communication', 104, 'COM-3349', 'Damaged', '2022-09-05'),
(205, 'JF-17 Thunder', 'Aircraft', 105, 'AIR-7781', 'Operational', '2023-11-20');



----------------------------Queries Used in backend-----------------------------------------
--------------------------------Personnel---------------------------------------------------
/*
-- Get all personnel
SELECT * FROM Personnel;

-- Get personnel by ID
SELECT * FROM Personnel WHERE P_ID = @P_ID;

-- Insert new personnel
INSERT INTO Personnel (P_ID, Name, Rank, UnitID) 
VALUES (@P_ID, @Name, @Rank, @UnitID);

-- Update personnel
UPDATE Personnel
SET Name = @Name, Rank = @Rank, UnitID = @UnitID
WHERE P_ID = @P_ID;

-- Delete personnel
DELETE FROM Personnel WHERE P_ID = @P_ID;

*/




---------------------------------------Operations-----------------------------------------------

/*
-- Get all operations
SELECT * FROM Operations;

-- Get operation by ID
SELECT * FROM Operations WHERE OP_ID = @OP_ID;

-- Insert new operation
INSERT INTO Operations (OP_ID, OP_Name, StartDate, EndDate, Status, Objective, CoalitionID)
VALUES (@OP_ID, @OP_Name, @StartDate, @EndDate, @Status, @Objective, @CoalitionID);

-- Update operation
UPDATE Operations
SET OP_Name = @OP_Name, StartDate = @StartDate, EndDate = @EndDate,
    Status = @Status, Objective = @Objective, CoalitionID = @CoalitionID
WHERE OP_ID = @OP_ID;

-- Delete operation
DELETE FROM Operations WHERE OP_ID = @OP_ID;

*/



------------------------------------Missions--------------------------------------------

/*
-- Get all missions
SELECT * FROM Missions;

-- Get mission by ID
SELECT * FROM Missions WHERE MI_ID = @MI_ID;

-- Insert new mission
INSERT INTO Missions (MI_ID, MissionName, StartTime, EndTime, OP_ID, AssignedUnitID)
VALUES (@MI_ID, @MissionName, @StartTime, @EndTime, @OP_ID, @AssignedUnitID);

-- Update mission
UPDATE Missions
SET MissionName = @MissionName, StartTime = @StartTime, EndTime = @EndTime,
    OP_ID = @OP_ID, AssignedUnitID = @AssignedUnitID
WHERE MI_ID = @MI_ID;

-- Delete mission
DELETE FROM Missions WHERE MI_ID = @MI_ID;
*/




---------------------------------------------Equipment Queries------------------------------------

/*
-- Get all equipment
SELECT * FROM Equipment;

-- Get equipment by ID
SELECT * FROM Equipment WHERE EQ_ID = @EQ_ID;

-- Insert new equipment
INSERT INTO Equipment (EQ_ID, Name, Type, UnitID, SerialNumber, Status, AcquiredDate)
VALUES (@EQ_ID, @Name, @Type, @UnitID, @SerialNumber, @Status, @AcquiredDate);

-- Update equipment
UPDATE Equipment
SET Name = @Name, Type = @Type, UnitID = @UnitID,
    SerialNumber = @SerialNumber, Status = @Status, AcquiredDate = @AcquiredDate
WHERE EQ_ID = @EQ_ID;

-- Delete equipment
DELETE FROM Equipment WHERE EQ_ID = @EQ_ID;
*/




--------------------------------------Units----------------------------------------------------

/*
-- Get all units
SELECT * FROM Units;

-- Get unit by ID
SELECT * FROM Units WHERE UnitID = @UnitID;

-- Insert new unit
INSERT INTO Units (UnitID, UnitName, Country, Type, OfficerID, Deployment, OP_ID)
VALUES (@UnitID, @UnitName, @Country, @Type, @OfficerID, @Deployment, @OperationID);

-- Update unit
UPDATE Units
SET UnitName = @UnitName, Country = @Country, Type = @Type,
    OfficerID = @OfficerID, Deployment = @Deployment, OP_ID = @OperationID
WHERE UnitID = @UnitID;

-- Delete unit
DELETE FROM Units WHERE UnitID = @UnitID;

*/





--------------------------------------Search & report-----------------------------------------------
/*
-- Search record (text field)
SELECT * FROM [TableName] WHERE [TextField] LIKE '%keyword%';

-- Search record (numeric field)
SELECT * FROM [TableName] WHERE [NumericField] = keyword;
*/